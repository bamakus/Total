select count(*)   as Nbr_doublons,TRANSACTION_ID,Filiale_ID_MON,VALUED_ITEM_ID,Filiale_ID_INV
 
 from   [dbo].[V_SRC_Fact_Transactions_2] source
 group by TRANSACTION_ID,Filiale_ID_MON,VALUED_ITEM_ID,Filiale_ID_INV
 HAVING   COUNT(*) > 1
 
 --les champs  sur les jointures 

   ON ISNULL(Target.TRANSACTION_ID,'')= ISNULL(Source.TRANSACTION_ID,'')
	 AND ISNULL(Target.Filiale_ID,'') = ISNULL(Source.Filiale_ID,'')
	 AND ISNULL(Target.VALUED_ITEM_ID,0)=ISNULL(Source.VALUED_ITEM_ID,0)
	 AND ISNULL(Target.Filiale_ID_INV,'') = ISNULL(Source.Filiale_ID_INV,'')

