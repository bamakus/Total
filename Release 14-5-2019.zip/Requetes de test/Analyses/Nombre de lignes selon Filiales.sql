--Nobre de liges selon fililales 
select [FileNameSrc_Auto] ,count(* ) from  [TCRD_STAG].[TCRD_STAG_CLIENTS_INV]
group by [FileNameSrc_Auto]

--Suppression les anciens donn�es 
DELETE FROM  [TCRD_STAG].[TCRD_STAG_CLIENTS_INV]
WHERE [FileNameSrc_Auto] IN ('Clients_Invoicing_2008_20190409.dat'
,'Clients_Invoicing_20331000_20190417.dat'

,'Clients_Invoicing_20332000_20190417.dat'
,'Clients_Invoicing_2049_20190409.dat')