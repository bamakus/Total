﻿Import-Module SqlServer
CD SQLSERVER:
$adminID =  "chrisherv@gmail.com"
$PlainPWord=  "Faouet1234"
$tableName= "Ventes"
$PlainPWord
$serverName="asazure://northeurope.asazure.windows.net/monserveurtabulaire"
$databaseName ="Vente2"

$PWord = ConvertTo-SecureString -String $PlainPWord -AsPlainText -Force
$Credential = New-Object -TypeName "System.Management.Automation.PSCredential" -ArgumentList $adminID, $PWord

Invoke-ProcessTable -Server $serverName -DatabaseName $databaseName -RefreshType Full -Credential $Credential -TableName $tableName
$_.Exception.Message