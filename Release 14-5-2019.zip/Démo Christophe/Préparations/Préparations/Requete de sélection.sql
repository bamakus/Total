SELECT * FROM Employee   
    FOR SYSTEM_TIME ALL 
	WHERE EmployeeID =1 and validfrom >=(select * from [dbo].[Last_Date_Insert])
	ORDER BY ValidFrom desc;  
