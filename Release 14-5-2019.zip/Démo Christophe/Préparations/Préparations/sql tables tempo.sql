--Affiche les lignes qui ont �t� actives pendant au moins une partie de la p�riode comprise entre le (>=) XXXXX & le YYYYY (<)  (limite sup�rieure comprise) 
SELECT * FROM Employee   
    FOR SYSTEM_TIME    
        BETWEEN '2018-06-26 06:45:59.00' AND '9999-12-31 23:59:59.99'   
            WHERE EmployeeID = 1 ORDER BY ValidFrom;  

-- A' cheval grace � la date '2018-06-26 06:45:59.00' 
SELECT * FROM Employee   
    FOR SYSTEM_TIME    
        BETWEEN '2018-06-26 06:43:43.64' AND '2018-06-26 06:45:59.00'   
            WHERE EmployeeID = 1 ORDER BY ValidFrom;

SELECT * FROM Employee   
    FOR SYSTEM_TIME    
        BETWEEN '2018-06-26 06:43:43.64' AND '2018-06-26 06:43:43.64'   
            WHERE EmployeeID = 1 ORDER BY ValidFrom;

SELECT * FROM Employee   
    FOR SYSTEM_TIME    
        BETWEEN '2018-06-26 06:45:59.00' AND '2018-06-26 06:45:59.00'   
            WHERE EmployeeID = 1 ORDER BY ValidFrom;


-- Affiche L�historique complet des modifications de donn�es pour cet employ�
SELECT * FROM Employee   
    FOR SYSTEM_TIME ALL WHERE    
        EmployeeID = 1 ORDER BY ValidFrom;  

-- Aspect que pr�sentait une table enti�re � n�importe quel point pass� dans le temps 
SELECT * FROM Employee FOR SYSTEM_TIME AS OF '2018-06-26 06:45:59.00' 
WHERE EmployeeID = 1

--Versions de lignes qui �taient actives uniquement pendant une p�riode (et pas en dehors de celle-ci)
  SELECT * FROM Employee FOR SYSTEM_TIME    
    CONTAINED IN ('2018-06-26 06:43:43.64', '2018-06-26 06:45:59.00')   
        WHERE EmployeeID = 1 ORDER BY ValidFrom;