SELECT package.packageName
	  ,cast(pre.starttime as date) AS DateDebutPackage
	  ,package.starttime AS DateHeureDebutPackage
	  ,packageEnd.endtime AS DateHeureFinPackage
	  ,CASE WHEN pre.source = package.packageName THEN NULL ELSE pre.source END AS NomTache
	  ,pre.starttime AS DateHeureDebutTache
	  ,post.endtime AS DateHeureFinTache
      ,Datediff(s,pre.starttime,post.endtime) AS Dur�eTacheSeconde
	  ,RIGHT('0' + CONVERT(varchar(5), Datediff(s,pre.starttime,post.endtime) / 3600), 2) + ':' + RIGHT('0' + CONVERT(varchar(5), Datediff(s,pre.starttime,post.endtime) % 3600 / 60), 2) + ':' + RIGHT('0' + CONVERT(varchar(5), Datediff(s,pre.starttime,post.endtime) % 60), 2) AS Dur�eTacheSecondeFormate
FROM   (SELECT source as packageName
			  ,executionid
			  ,starttime
			  ,endtime
		FROM   dbo.sysssislog
        WHERE  [event] = 'PackageStart'
		AND source = 'Exp_ElementsValorises'
		) package
LEFT JOIN (SELECT source as packageName
                   ,executionid
                   ,starttime
                   ,endtime
            FROM   dbo.sysssislog
            WHERE  [event] = 'PackageEnd') packageEnd ON  package.executionid = packageEnd.executionid
LEFT JOIN (SELECT starttime
                   ,endtime
                   ,executionid
                   ,source
                   ,event
                   ,sourceid
            FROM   dbo.sysssislog
            WHERE  [event] = 'OnPreExecute') pre ON  package.executionid = pre.executionid
LEFT JOIN (SELECT starttime
                   ,endtime
                   ,executionid
                   ,source
                   ,sourceid
            FROM   dbo.sysssislog
            WHERE  [event] = 'OnPostExecute') post ON pre.executionid = post.executionid AND pre.sourceid = post.sourceid
WHERE package.starttime > Dateadd(d, -1, Getdate())
AND package.packageName = 'Exp_ElementsValorises'
order by DateHeureFinTache desc