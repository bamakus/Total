 UPDATE A
 SET ID_TEC_PRODUCT = B.ID_TEC_PRODUCT
 FROM [dbo].[TCRD_DWH_TRANSACTIONS] A 
  INNER JOIN [dbo].[TCRD_DWH_Produits] B
  On A.Product_ID=B.Product_id
  AND A.Filiale_id = B.Filiale_id
  AND ISNULL(A.Filiale_id_INV,'') = ISNULL(B.Filiale_id_INV,'') 
  WHERE A.ID_TEC_PRODUCT = -1